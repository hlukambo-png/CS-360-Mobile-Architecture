# CS 360 Project Three - StockKeeper Inventory App
**Student:** Heri Lukambo  
**App option:** Option 1 - Inventory App  
**Language:** Java | **Storage:** SQLite (offline/local) | **Android:** API 26-37

## Import and build in Android Studio
1. Install the **Android 17 / API 37 SDK** and use Android Studio Panda 3 or newer with **JDK 17**.
2. Extract the ZIP. On Windows, double-click **`SETUP_GRADLE_WRAPPER.bat`** (with internet access) to download and SHA-256 verify the official Gradle wrapper JAR. Then choose **File > Open**, and select the extracted `CS360_Project_Three_Inventory_App_Heri_Lukambo` folder.
3. Let Gradle sync. This project uses **Android Gradle Plugin 9.1.1** and **Gradle 9.3.1**; Android Studio may download them on first sync.
4. Start a phone emulator (preferably API 37; API 26+ is also supported), then click **Run app**.
5. If wrapper setup fails, choose Gradle **9.3.1** in Android Studio Gradle settings, or run `gradle wrapper` if Gradle 9.3.1 is already installed. The wrapper JAR is not prebundled; the included setup batch file securely fetches and checks the official JAR on your computer.

## Test against Project Three rubric
- **Registration:** Create username `tester1` and password `password123`. Log out and log back in. Invalid passwords should fail.
- **Persisted accounts:** Force stop/reopen; log in using the same credentials.
- **CRUD:** Add "Shipping boxes" with quantity 2, then test Edit, +, -, Delete with confirmation. After app restart, verify item persists. Add a second account and verify the first account's items are not visible.
- **Grid:** Verify 2-column item cards on a normal portrait emulator, with status text and quantities.
- **SMS enabled:** From **SMS Alerts**, enter a test destination number (another emulator phone such as `5554`) and enable alerts. Grant SMS permission. Decrease an item from 1 to 0; the app attempts an SMS. An SMS-enabled emulator or phone is required to actually deliver it.
- **SMS denied:** Revoke `SEND_SMS` in system Settings (or deny when prompted); change an item's quantity, add/edit/delete items, and verify the database still works. No SMS should be attempted while permission is denied.
- **No phone hardware:** Login and inventory still work on a Wi-Fi-only emulator/tablet; optional SMS cannot be enabled.

## Technical overview
- `LoginActivity` validates input, registers local users, and authenticates saved passwords.
- `DatabaseHelper` creates `users` and `inventory` SQLite tables, separates inventories by account and handles CRUD.
- `PasswordHasher` uses random per-account salts and PBKDF2-HMAC-SHA256 to avoid plaintext passwords.
- `InventoryActivity` displays a grid of persisted records, validates quantity, confirms deletion, and requests optional SMS permission.
- `SmsNotifier` performs permission/device checks before attempting a zero-stock SMS.
- No sample inventory rows are preloaded, by design.

## Important launch distinction
`SEND_SMS` is implemented for the **course rubric's classroom demonstration**. Google Play restricts SMS permissions to specific permitted uses and default handlers. This ordinary inventory app must **not** be submitted publicly to Google Play with `SEND_SMS` as-is; a production launch would use app notifications or an SMS-compose intent that does not request `SEND_SMS`.

## Limitations / review
This is a source-code project. It was **not independently compiled inside this packaging environment**, where Android SDK/Gradle tools were unavailable. The student reported a successful Gradle build and completed manual emulator tests on their own computer on October 19, 2026, summarized in `TEST_RESULTS.md`. No APK or proof of delivery to a real phone is included. If changes were made locally after downloading the original project, export that local project separately, because this ZIP cannot automatically capture them.
