package com.herilukambo.stockkeeper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** SQLite repository: all database work stays outside the Activity classes. */
public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "stockkeeper.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL COLLATE NOCASE UNIQUE, " +
                "salt TEXT NOT NULL, password_hash TEXT NOT NULL, " +
                "alert_phone TEXT NOT NULL DEFAULT '', " +
                "sms_enabled INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE inventory (" +
                "item_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "owner_id INTEGER NOT NULL, " +
                "item_name TEXT NOT NULL COLLATE NOCASE, " +
                "quantity INTEGER NOT NULL CHECK(quantity >= 0), " +
                "UNIQUE(owner_id, item_name), " +
                "FOREIGN KEY(owner_id) REFERENCES users(user_id) ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 is the initial schema. Add migrations here in future releases
        // rather than dropping persistent user or inventory data.
    }

    /** Returns -1 for a username already in use; otherwise the created user ID. */
    public long register(String username, String password) {
        String salt = PasswordHasher.newSalt();
        ContentValues data = new ContentValues();
        data.put("username", username);
        data.put("salt", salt);
        data.put("password_hash", PasswordHasher.hash(password, salt));
        return getWritableDatabase().insertWithOnConflict("users", null, data,
                SQLiteDatabase.CONFLICT_IGNORE);
    }

    /** Returns the account ID only when both username and password match. */
    public long login(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query("users",
                new String[]{"user_id", "salt", "password_hash"}, "username = ?",
                new String[]{username}, null, null, null)) {
            if (!cursor.moveToFirst()) return -1;
            return PasswordHasher.verify(password, cursor.getString(1), cursor.getString(2))
                    ? cursor.getLong(0) : -1;
        }
    }

    public String getUsername(long userId) {
        try (Cursor cursor = getReadableDatabase().query("users", new String[]{"username"},
                "user_id = ?", new String[]{Long.toString(userId)}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getString(0) : null;
        }
    }

    public List<Item> getItems(long ownerId) {
        List<Item> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("inventory",
                new String[]{"item_id", "item_name", "quantity"}, "owner_id = ?",
                new String[]{Long.toString(ownerId)}, null, null,
                "item_name COLLATE NOCASE ASC")) {
            while (cursor.moveToNext()) {
                items.add(new Item(cursor.getLong(0), cursor.getString(1), cursor.getInt(2)));
            }
        }
        return items;
    }

    public long addItem(long ownerId, String name, int quantity) {
        ContentValues row = new ContentValues();
        row.put("owner_id", ownerId);
        row.put("item_name", name);
        row.put("quantity", quantity);
        return getWritableDatabase().insertWithOnConflict("inventory", null, row,
                SQLiteDatabase.CONFLICT_IGNORE);
    }

    public boolean editItem(long ownerId, long itemId, String name, int quantity) {
        ContentValues row = new ContentValues();
        row.put("item_name", name);
        row.put("quantity", quantity);
        // Database uniqueness protects against duplicate item names per user.
        return getWritableDatabase().updateWithOnConflict("inventory", row,
                "item_id = ? AND owner_id = ?",
                new String[]{Long.toString(itemId), Long.toString(ownerId)},
                SQLiteDatabase.CONFLICT_IGNORE) == 1;
    }

    public boolean changeQuantity(long ownerId, long itemId, int quantity) {
        ContentValues row = new ContentValues();
        row.put("quantity", quantity);
        return getWritableDatabase().update("inventory", row,
                "item_id = ? AND owner_id = ?",
                new String[]{Long.toString(itemId), Long.toString(ownerId)}) == 1;
    }

    public boolean deleteItem(long ownerId, long itemId) {
        return getWritableDatabase().delete("inventory", "item_id = ? AND owner_id = ?",
                new String[]{Long.toString(itemId), Long.toString(ownerId)}) == 1;
    }

    public AlertSettings getAlerts(long ownerId) {
        try (Cursor cursor = getReadableDatabase().query("users",
                new String[]{"alert_phone", "sms_enabled"}, "user_id = ?",
                new String[]{Long.toString(ownerId)}, null, null, null)) {
            if (cursor.moveToFirst()) {
                return new AlertSettings(cursor.getString(0), cursor.getInt(1) == 1);
            }
            return new AlertSettings("", false);
        }
    }

    public void saveAlerts(long ownerId, String phone, boolean enabled) {
        ContentValues row = new ContentValues();
        row.put("alert_phone", phone);
        row.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update("users", row, "user_id = ?",
                new String[]{Long.toString(ownerId)});
    }

    public static final class AlertSettings {
        public final String phone;
        public final boolean enabled;

        public AlertSettings(String phone, boolean enabled) {
            this.phone = phone;
            this.enabled = enabled;
        }
    }
}
