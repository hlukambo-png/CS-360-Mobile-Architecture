package com.herilukambo.stockkeeper;

import android.view.View;
import android.view.WindowInsets;

/** Keeps important controls clear of system bars on edge-to-edge devices. */
public final class InsetsHelper {
    private InsetsHelper() { }

    public static void apply(View view) {
        final int left = view.getPaddingLeft();
        final int top = view.getPaddingTop();
        final int right = view.getPaddingRight();
        final int bottom = view.getPaddingBottom();
        view.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(left + insets.getSystemWindowInsetLeft(),
                    top + insets.getSystemWindowInsetTop(),
                    right + insets.getSystemWindowInsetRight(),
                    bottom + insets.getSystemWindowInsetBottom());
            return insets;
        });
        view.requestApplyInsets();
    }
}
