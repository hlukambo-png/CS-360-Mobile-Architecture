package com.herilukambo.stockkeeper;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

/** Main inventory screen: a persistent SQLite-backed grid with CRUD controls. */
public final class InventoryActivity extends Activity {
    public static final String EXTRA_USER_ID = "user_id";
    private static final int REQUEST_SEND_SMS = 7;
    private DatabaseHelper database;
    private long userId;
    private GridLayout itemsGrid;
    private TextView emptyLabel;
    private TextView summaryLabel;
    private String pendingPhone;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_inventory);
        InsetsHelper.apply(findViewById(R.id.inventoryRoot));
        database = new DatabaseHelper(this);
        userId = getIntent().getLongExtra(EXTRA_USER_ID, -1);
        String username = database.getUsername(userId);
        if (username == null) {
            Toast.makeText(this, "Please log in", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        ((TextView) findViewById(R.id.welcomeLabel)).setText("Inventory · " + username);
        summaryLabel = findViewById(R.id.summaryLabel);
        itemsGrid = findViewById(R.id.itemsGrid);
        emptyLabel = findViewById(R.id.emptyLabel);
        findViewById(R.id.addItemButton).setOnClickListener(v -> showItemDialog(null));
        findViewById(R.id.smsSettingsButton).setOnClickListener(v -> showSmsSettings());
        findViewById(R.id.logoutButton).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
        refreshGrid();
    }

    private void refreshGrid() {
        List<Item> items = database.getItems(userId);
        itemsGrid.removeAllViews();
        int columns = getResources().getConfiguration().screenWidthDp >= 600 ? 3
                : (getResources().getConfiguration().screenWidthDp >= 340 ? 2 : 1);
        itemsGrid.setColumnCount(columns);
        int width = getResources().getDisplayMetrics().widthPixels;
        int tileWidth = (width - dp(40) - (columns - 1) * dp(12)) / columns;
        int zeros = 0;
        for (int i = 0; i < items.size(); i++) {
            Item item = items.get(i);
            if (item.quantity == 0) zeros++;
            View tile = LayoutInflater.from(this).inflate(R.layout.item_card, itemsGrid, false);
            ((TextView) tile.findViewById(R.id.itemName)).setText(item.name);
            ((TextView) tile.findViewById(R.id.itemQuantity)).setText(String.valueOf(item.quantity));
            TextView stockLabel = tile.findViewById(R.id.itemStatus);
            stockLabel.setText(item.quantity == 0 ? "OUT OF STOCK" : "Units available");
            if (item.quantity == 0) stockLabel.setTextColor(getColor(R.color.alert));
            tile.findViewById(R.id.decreaseButton).setOnClickListener(v -> changeQuantity(item, -1));
            tile.findViewById(R.id.increaseButton).setOnClickListener(v -> changeQuantity(item, 1));
            tile.findViewById(R.id.editButton).setOnClickListener(v -> showItemDialog(item));
            tile.findViewById(R.id.deleteButton).setOnClickListener(v -> confirmDelete(item));
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = tileWidth;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.setMargins(0, 0, (i % columns == columns - 1) ? 0 : dp(12), dp(12));
            itemsGrid.addView(tile, params);
        }
        emptyLabel.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        summaryLabel.setText(items.size() + " items · " + zeros + " out of stock");
    }

    private void changeQuantity(Item item, int step) {
        if (step < 0 && item.quantity == 0) {
            toast("Quantity cannot go below zero");
            return;
        }
        if (step > 0 && item.quantity == Integer.MAX_VALUE) {
            toast("Quantity cannot go any higher");
            return;
        }
        int next = item.quantity + step;
        if (database.changeQuantity(userId, item.id, next)) {
            refreshGrid();
            if (item.quantity > 0 && next == 0) onOutOfStock(item.name);
        } else {
            toast("Could not save quantity");
        }
    }

    private void showItemDialog(Item oldItem) {
        View body = LayoutInflater.from(this).inflate(R.layout.dialog_item, null);
        EditText nameInput = body.findViewById(R.id.nameInput);
        EditText quantityInput = body.findViewById(R.id.quantityInput);
        if (oldItem != null) {
            nameInput.setText(oldItem.name);
            quantityInput.setText(String.valueOf(oldItem.quantity));
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(oldItem == null ? "Add inventory item" : "Edit inventory item")
                .setView(body).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(DialogInterface.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = nameInput.getText().toString().trim();
                    String rawQuantity = quantityInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        nameInput.setError("Enter an item name");
                        return;
                    }
                    int quantity;
                    try {
                        quantity = Integer.parseInt(rawQuantity);
                        if (quantity < 0) throw new NumberFormatException();
                    } catch (NumberFormatException ex) {
                        quantityInput.setError("Enter a whole number from 0 to 2147483647");
                        return;
                    }
                    boolean saved = oldItem == null
                            ? database.addItem(userId, name, quantity) != -1
                            : database.editItem(userId, oldItem.id, name, quantity);
                    if (!saved) {
                        nameInput.setError("An item with this name may already exist");
                        return;
                    }
                    dialog.dismiss();
                    refreshGrid();
                    if (quantity == 0 && (oldItem == null || oldItem.quantity > 0)) {
                        onOutOfStock(name);
                    }
                }));
        dialog.show();
    }

    private void confirmDelete(Item item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete " + item.name + "?")
                .setMessage("This item will be removed from inventory. This cannot be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (ignored, which) -> {
                    if (database.deleteItem(userId, item.id)) {
                        refreshGrid();
                        toast("Item deleted");
                    } else {
                        toast("Could not delete item");
                    }
                }).show();
    }

    private void showSmsSettings() {
        DatabaseHelper.AlertSettings previous = database.getAlerts(userId);
        View body = LayoutInflater.from(this).inflate(R.layout.dialog_sms, null);
        EditText phoneInput = body.findViewById(R.id.phoneInput);
        CheckBox enabledInput = body.findViewById(R.id.enableSmsCheckbox);
        phoneInput.setText(previous.phone);
        enabledInput.setChecked(previous.enabled);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Zero-stock SMS alerts")
                .setView(body).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(DialogInterface.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String phone = phoneInput.getText().toString().trim().replaceAll("[ ()-]", "");
                    if (!enabledInput.isChecked()) {
                        database.saveAlerts(userId, phone, false);
                        dialog.dismiss();
                        toast("SMS alerts disabled; inventory still works");
                        return;
                    }
                    // Four digits also supports emulator-to-emulator test numbers (e.g., 5554).
                    if (!phone.matches("\\+?[0-9]{4,15}")) {
                        phoneInput.setError("Enter 4–15 digits, optionally starting with +");
                        return;
                    }
                    if (!getPackageManager().hasSystemFeature(
                            PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
                        toast("This device cannot send SMS; other features still work");
                        return;
                    }
                    dialog.dismiss();
                    if (checkSelfPermission(Manifest.permission.SEND_SMS)
                            == PackageManager.PERMISSION_GRANTED) {
                        database.saveAlerts(userId, phone, true);
                        toast("SMS alerts enabled");
                    } else {
                        pendingPhone = phone;
                        requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQUEST_SEND_SMS);
                    }
                }));
        dialog.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQUEST_SEND_SMS || pendingPhone == null) return;
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        database.saveAlerts(userId, pendingPhone, granted);
        pendingPhone = null;
        toast(granted ? "SMS alerts enabled" : "SMS denied; inventory will continue to work");
    }

    private void onOutOfStock(String itemName) {
        toast(SmsNotifier.sendZeroStockAlert(this, database.getAlerts(userId), itemName));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
