package com.herilukambo.stockkeeper;

/** Immutable item data passed from the SQLite layer to the inventory screen. */
public final class Item {
    public final long id;
    public final String name;
    public final int quantity;

    public Item(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }
}
