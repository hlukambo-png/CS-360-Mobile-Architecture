package com.herilukambo.stockkeeper;

import android.util.Base64;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Stores salted password derivations instead of plaintext passwords. */
public final class PasswordHasher {
    private static final int ITERATIONS = 120_000;
    private static final int KEY_LENGTH_BITS = 256;
    private static final int SALT_BYTES = 16;

    private PasswordHasher() { }

    public static String newSalt() {
        byte[] bytes = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(bytes);
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    public static String hash(String password, String encodedSalt) {
        char[] chars = password.toCharArray();
        PBEKeySpec spec = new PBEKeySpec(chars, Base64.decode(encodedSalt, Base64.NO_WRAP),
                ITERATIONS, KEY_LENGTH_BITS);
        try {
            byte[] derived = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            return Base64.encodeToString(derived, Base64.NO_WRAP);
        } catch (GeneralSecurityException ex) {
            throw new IllegalStateException("Secure password hashing is unavailable", ex);
        } finally {
            spec.clearPassword();
            java.util.Arrays.fill(chars, '\0');
        }
    }

    public static boolean verify(String candidate, String salt, String savedHash) {
        byte[] expected = Base64.decode(savedHash, Base64.NO_WRAP);
        byte[] actual = Base64.decode(hash(candidate, salt), Base64.NO_WRAP);
        return MessageDigest.isEqual(expected, actual);
    }
}
