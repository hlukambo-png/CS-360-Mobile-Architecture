package com.herilukambo.stockkeeper;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

/** Optional SMS sender: permission and hardware are checked on every alert. */
public final class SmsNotifier {
    private SmsNotifier() { }

    public static String sendZeroStockAlert(Context context,
                                            DatabaseHelper.AlertSettings settings,
                                            String itemName) {
        if (!settings.enabled) return "SMS alerts are off; inventory was saved.";
        if (context.checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return "SMS permission is unavailable; inventory was saved.";
        }
        if (!context.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
            return "SMS hardware is unavailable; inventory was saved.";
        }
        try {
            // Android will route through the selected/default SMS subscription.
            SmsManager.getDefault().sendTextMessage(settings.phone, null,
                    "StockKeeper: " + itemName + " is out of stock (quantity 0).",
                    null, null);
            return "Out-of-stock SMS submitted to the device.";
        } catch (RuntimeException exception) {
            return "SMS could not be sent; inventory was saved.";
        }
    }
}
