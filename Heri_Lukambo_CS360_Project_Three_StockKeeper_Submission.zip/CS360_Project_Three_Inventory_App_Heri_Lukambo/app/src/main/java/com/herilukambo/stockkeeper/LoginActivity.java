package com.herilukambo.stockkeeper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/** Entry screen for new-account registration and existing-account login. */
public final class LoginActivity extends Activity {
    private DatabaseHelper database;
    private EditText usernameInput;
    private EditText passwordInput;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_login);
        InsetsHelper.apply(findViewById(R.id.loginRoot));
        database = new DatabaseHelper(this);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.createAccountButton);
        loginButton.setOnClickListener(v -> submit(false));
        registerButton.setOnClickListener(v -> submit(true));
    }

    private void submit(boolean newAccount) {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        if (!username.matches("[A-Za-z0-9._-]{3,30}")) {
            usernameInput.setError("Use 3–30 letters, numbers, . _ or -");
            return;
        }
        if (password.isEmpty() || (newAccount && password.length() < 8)) {
            passwordInput.setError(newAccount ? "Use at least 8 characters" : "Enter your password");
            return;
        }

        try {
            long userId = newAccount ? database.register(username, password)
                    : database.login(username, password);
            if (userId < 0) {
                Toast.makeText(this, newAccount ? "Username is already taken"
                        : "Incorrect username or password", Toast.LENGTH_LONG).show();
                return;
            }
            // Do not keep a copy of the password in the next screen's Intent.
            passwordInput.setText("");
            Intent intent = new Intent(this, InventoryActivity.class);
            intent.putExtra(InventoryActivity.EXTRA_USER_ID, userId);
            startActivity(intent);
            finish();
        } catch (RuntimeException exception) {
            Toast.makeText(this, "Unable to access local account data", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
