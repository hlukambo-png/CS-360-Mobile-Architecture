# CS 360 Project Three — StockKeeper Test Record

Student: Heri Lukambo  
Option: Inventory Application  
Test environment: Android Studio / Pixel Android Emulator  
Recorded: October 19, 2026

## Functional tests reported by student during final verification

| Feature | Result | Notes |
|---|---|---|
| Gradle build | PASS | Android Studio reported "Build successful for 1 module" |
| Installation and launch | PASS | StockKeeper displayed and inventory screen opened on Pixel emulator |
| Account creation and login | PASS | New account created, inventory dashboard accessible |
| Login validation | PASS | Incorrect password rejected |
| Inventory create | PASS | Added an inventory item successfully |
| Inventory read | PASS | Item visible in inventory grid |
| Inventory update | PASS | Quantity changed using increase/decrease buttons |
| Inventory delete | PASS | Selected item was deleted |
| Local persistence | PASS | Saved inventory remained after closing and reopening app |
| Optional SMS alert trigger | PASS (submission reported) | "Out-of-stock SMS submitted to the device" appeared on reaching zero |
| Continued inventory use | PASS (reported) | Item saved while testing the SMS permission choice |
| SMS delivered to physical phone | NOT VERIFIED | The Android emulator is not a normal cellular device; sending attempt is not evidence of receipt |

These are the student's observed results discussed during the testing walkthrough, not independent emulator tests performed as part of packaging. No APK is included because the verified Android Studio build occurred on the student's computer, not in this packaging environment.

## Submission contents

The project directory contains Java source code, layouts, manifest, Gradle configuration, and an optional Windows setup helper for the official Gradle wrapper JAR. Open the included Gradle project directory in Android Studio; do not open this test record as a project.
