@echo off
setlocal
cd /d "%~dp0"
echo Downloading and verifying the official Gradle 9.3.1 wrapper...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $url='https://services.gradle.org/distributions/gradle-9.3.1-wrapper.jar'; $path=Join-Path (Get-Location).Path 'gradle\wrapper\gradle-wrapper.jar'; Invoke-WebRequest -Uri $url -OutFile $path; $expected=((Invoke-WebRequest -Uri ($url + '.sha256')).Content).Trim().Split(' ')[0].ToLowerInvariant(); $actual=(Get-FileHash -Path $path -Algorithm SHA256).Hash.ToLowerInvariant(); if($expected -ne $actual){ Remove-Item $path; throw 'Gradle wrapper checksum mismatch' }; Write-Host 'Official Gradle wrapper verified.'"
if errorlevel 1 (
  echo Setup failed. Check your internet connection.
  pause
  exit /b 1
)
echo You can now open this folder in Android Studio.
pause
